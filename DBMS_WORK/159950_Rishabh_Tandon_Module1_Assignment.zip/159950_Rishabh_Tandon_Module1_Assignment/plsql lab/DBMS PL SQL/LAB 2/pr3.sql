create or replace procedure FIND_COMM(
	empCode in employee.empno%TYPE)
is
	empCol employee.comm%TYPE;
	COMM_NULL EXCEPTION;
begin
	select comm into empCol
	from employee
	where empno = empCode;
	IF (empCol IS NULL) THEN
		RAISE COMM_NULL;
	END IF;

EXCEPTION
	WHEN COMM_NULL THEN
		DBMS_OUTPUT.PUT_LINE('The employee with empno ' || empCode || ' has no commission assigned.');
	
end ;
/	

exec FIND_COMM(7369);
/