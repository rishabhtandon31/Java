create or replace function age(
	dob in date)
	return number IS
	age number(8) := 0;
begin
	select months_between(sysdate, dob) / 12 into age
	from dual;
	return age;
end;
/

begin
	dbms_output.put_line(age(to_date('3-02-2002','DD-MM-YYYY')));
end;
/	