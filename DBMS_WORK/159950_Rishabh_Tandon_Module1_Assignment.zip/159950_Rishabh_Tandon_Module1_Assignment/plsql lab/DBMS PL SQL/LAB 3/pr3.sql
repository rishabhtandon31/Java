create or replace function Cost(
	stcode in staff_master.staff_code%TYPE)
	return number IS
	tcost number(10) := 0;
	da number(10) := 0;
	hra number(10) := 0;
	ta number(10) := 0;
	sa number(10) := 0;
	hd date;
	yrs number(10) := 0;
begin
	select staff_sal, hiredate into tcost, hd
	from staff_master
	where staff_code = stcode;
	da := 0.15 * tcost;
	hra := 0.2 * tcost;
	ta := 0.08 * tcost;
	yrs := (months_between(sysdate, hd) / 12);
	IF (yrs<1) THEN 
		sa := 0.1 * tcost;
	ELSIF (yrs >=1 and yrs<2) THEN 
		sa := 0.2 * tcost;
	ELSIF (yrs >=2 and yrs<4) THEN 
		sa := 0.3 * tcost;
	ELSE
		sa := 0.3 * tcost;
	END IF;
	tcost := tcost + da + hra + ta + sa;
	return tcost;
end;
/

begin 
	dbms_output.put_line(Cost(101));
end;
/	