select * from all_index
	where index LIKE '%No_Name%';