CREATE TABLE Department_Master
(
	Dept_Code number(2) Not Null,
	Dept_name varchar2(50)
);