INSERT INTO employee
(empno, ename, sal, deptno)
values(7369, 'SMITH',800,20);

INSERT INTO employee
(empno, ename, sal, deptno)
values(7499, 'ALLEN',1600,30);

INSERT INTO employee
(empno, ename, sal, deptno)
values(7521, 'WARD',1250,30);

INSERT INTO employee
(empno, ename, sal, deptno)
values(7566, 'JONES',2975,20);


INSERT INTO employee
(empno, ename, sal, deptno)
values(7654, 'MARTIN',1250,30);

INSERT INTO employee
(empno, ename, sal, deptno)
values(7698, 'BLAKE',2850,30);

INSERT INTO employee
(empno, ename, sal, deptno)
values(7788, 'CLARK',2450,10);

INSERT INTO employee
(empno, ename, sal, deptno)
values(7788, 'SCOTT',3000,20);

INSERT INTO employee
(empno, ename, sal, deptno)
values(7839, 'KING',5000,10);

INSERT INTO employee
(empno, ename, sal, deptno)
values(7844, 'TURNER',950,30);

INSERT INTO employee
(empno, ename, sal, deptno)
values(7876, 'ADAMS',1100,20);

INSERT INTO employee
(empno, ename, sal, deptno)
values(7900, 'JAMES',950,30);

INSERT INTO employee
(empno, ename, sal, deptno)
values(7902, 'FORD',3000,20);

INSERT INTO employee
(empno, ename, sal, deptno)
values(7934, 'MILLER',1300,10);