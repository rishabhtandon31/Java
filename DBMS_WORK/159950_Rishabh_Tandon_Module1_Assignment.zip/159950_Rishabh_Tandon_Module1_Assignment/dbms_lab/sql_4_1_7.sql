ALTER table cust_table
disable constraint Custld_Prim;