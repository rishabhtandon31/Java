CREATE TABLE Customer1
(CustomerId number(5),
Cust_Name varchar(20),
Address1 varchar2(30),
Address2 varchar2(30)
);