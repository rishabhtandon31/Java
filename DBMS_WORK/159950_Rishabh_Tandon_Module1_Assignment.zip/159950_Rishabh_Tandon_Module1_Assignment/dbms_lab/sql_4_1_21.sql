CREATE Table AccountDetails 
as select * from AccountMaster;