ALTER TABLE cust_table
add email varchar2(15);