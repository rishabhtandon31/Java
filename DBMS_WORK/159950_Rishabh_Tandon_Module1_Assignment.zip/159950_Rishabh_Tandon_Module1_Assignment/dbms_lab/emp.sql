CREATE TABLE EMP
(
	Empno number(4) NOT NULL,
	Ename varchar2(10),
	job varchar2(9),
	mgr number(4),
	hiredate date,
	Sal number(7,2),
	Comm number(7,2),
	Deptno number(2)
);