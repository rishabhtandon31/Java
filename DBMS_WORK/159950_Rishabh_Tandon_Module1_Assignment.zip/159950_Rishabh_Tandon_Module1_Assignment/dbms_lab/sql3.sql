SELECT * from staff_master
where mgr_code is NULL;