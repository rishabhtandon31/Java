ALTER Table Customer1
modify Cust_name Varchar2(30) NOT NULL;

ALTER Table Customer1
rename column Cust_name to CustomerName;
