ALTER TABLE cust_table
drop column email;