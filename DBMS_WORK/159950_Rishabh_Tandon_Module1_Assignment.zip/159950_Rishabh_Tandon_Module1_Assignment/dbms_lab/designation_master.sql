CREATE TABLE Designation_Master
(
	Design_code number(3) Not Null,
	Design_name varchar2(50)
);