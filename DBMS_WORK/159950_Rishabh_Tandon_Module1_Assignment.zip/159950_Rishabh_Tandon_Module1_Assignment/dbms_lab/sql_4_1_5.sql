ALTER Table cust_table
add constraint Custld_Prim PRIMARY KEY (CustomerId) ;