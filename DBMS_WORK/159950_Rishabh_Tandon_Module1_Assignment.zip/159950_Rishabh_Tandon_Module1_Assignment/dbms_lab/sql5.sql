SELECT * from Staff_Master
where staff_name like '%\_%' ESCAPE '\';