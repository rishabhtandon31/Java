INSERT INTO employee
values(1000,'Allen', 'Clerk',1001,to_date('12-jan-01','DD-MON-YY'), 3000, 2,10);

INSERT INTO employee
values(1001,'George', 'analyst', null, to_date('08 Sep 92','DD MON YY'), 5000,0, 10);

INSERT INTO employee
values(1002, 'Becker', 'Manager', 1000, to_date('4 Nov 92','DD MON YY', 2800,4, 20);

INSERT INTO employee
values(1003, 'Bill', Clerk, 1002, to_date('4 Nov 92','DD MON YY'),3000, 0, 20), 3000, 2,10);

