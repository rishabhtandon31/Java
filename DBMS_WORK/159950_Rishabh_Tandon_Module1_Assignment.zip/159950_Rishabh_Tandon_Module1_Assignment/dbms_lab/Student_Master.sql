CREATE TABLE Student_Master
(
	student_code number(6) Not Null,
	student_name varchar2(50) Not Null,
	dept_code number(2),
	student_dob date,
	student_address varchar2(240)
);