SELECT Name as "Staff Name" ,design_code as "Designation Code" from STAFF_Master
where hiredate < 'Jan 2003' and staff_sal between 12000 and 25000;