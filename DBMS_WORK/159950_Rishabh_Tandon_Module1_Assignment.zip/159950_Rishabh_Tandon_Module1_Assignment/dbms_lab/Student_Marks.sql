CREATE TABLE Student_Marks
(
	student_code number(6),
	student_year number Not Null,
	subject1 number(3),
	subject2 number(3),
	subject3 number(3)
);