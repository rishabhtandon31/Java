ALTER table cust_table
enable constraint Custld_Prim;