ALTER Table Customer1
add (Gender Varchar2(1),
Age	Number(3),
PhoneNo	Number(10));

ALTER Table Customer1 rename to Cust_table;