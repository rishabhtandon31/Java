SELECT round(MAX(staff_sal)), round(MIN(staff_sal)), round(SUM(staff_sal)), round(AVG(staff_sal)) 
from staff_master;