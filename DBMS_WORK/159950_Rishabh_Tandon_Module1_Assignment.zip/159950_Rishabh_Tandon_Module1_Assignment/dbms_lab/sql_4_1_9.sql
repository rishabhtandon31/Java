ALTER table cust_table
drop constraint Custld_Prim;

INSERT INTO cust_table
values(1002, 'Becker', '#114 New York', '#114 New york' , 'M', 45, 431525, 15000.50);


INSERT INTO cust_table
values(1003, 'Nanapatekar', '#115 India', '#115 India' , 'M', 45, 431525, 20000.50);