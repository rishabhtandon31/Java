import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class StringSorting {
	public static void main(String[] args) {
		String [] c={"Brush","Biscuits","Hat"};
		Arrays.sort(c);
		
		ArrayList<String> arr =new ArrayList<String>();
		arr.add("Gel");
		arr.add("Accessories");
		arr.add("Brush");
		
		Collections.sort(arr);
		for (String string : arr) {
			System.out.println(string);
		}
		
		
		
		/*for (String string : c) {
			System.out.println(string);
		}*/
	}

}
